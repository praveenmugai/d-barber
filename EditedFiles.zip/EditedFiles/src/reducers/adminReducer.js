import { GET_PROFILE_DETAILS, SETTINGS, SAVE_SETTINGS } from "../actions/homeActions";

const INITIAL_STATE = {
  userData: '',
};

function homeReducer(state = INITIAL_STATE, action) {
  switch (action.type) {
    case GET_PROFILE_DETAILS:
      return { ...state, userData: action.data };
    case SETTINGS:
      return { ...state, settings: action.data };
    case SAVE_SETTINGS:
      return { ...state, saveSettings: action.data };
    default: return state;
  }
}

export default homeReducer;
