import { combineReducers } from 'redux';

import adminReducer from './adminReducer';
import vendorsReducer from './vendorsReducer';
import usersReducer from "./usersReducer";
import customersReducer from "./customersReducer";
import bookingsReducer from "./bookingsReducer";
import offersReducer from "./offersReducer";
import employeyesReducer from "./employeesReducer";
import servicesReducer from "./servicesReducer";

const rootReducer = combineReducers({
  adminState: adminReducer,
  vendorState: vendorsReducer,
  userState: usersReducer,
  customerState: customersReducer,
  bookingState: bookingsReducer,
  offerState: offersReducer,
  employeeState: employeyesReducer,
  serviceState: servicesReducer
});

export default rootReducer;