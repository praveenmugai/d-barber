import { GET_VENDORS, ADD_VENDOR, GET_VENDOR_DETAILS, GET_TOP_VENDORS } from "../actions/vendorActions";

const INITIAL_STATE = {
  vendors: [],
  addVendor: null,
  vendorDetails: null
};

function vendorsReducer(state = INITIAL_STATE, action) {
  switch (action.type) {
    case GET_VENDORS:
      return {...state, vendors: action.data};
    case GET_TOP_VENDORS:
      return {...state, topvendors: action.data};
    case ADD_VENDOR:
      return {...state, addVendor: action.data};
    case GET_VENDOR_DETAILS:
      return {...state, vendorDetails: action.data};
    default: return state;
  }
}

export default vendorsReducer;
