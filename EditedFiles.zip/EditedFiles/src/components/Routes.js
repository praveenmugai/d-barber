import loadable from '@loadable/component';
import React from 'react';
import {  Route, Switch, Redirect } from 'react-router-dom';
import { getLoggedInUser } from '../globals/utils';

const publicPath = '/';
export const routeCodes = {
  DASHBOARD: publicPath,
  LOGIN: `${publicPath}login`,
  REGISTER: `${publicPath}register`,
  VENDORS_LIST: `${publicPath}vendor`,
  VENDOR_DETAILS: `${publicPath}vendor-details`,
  BOOKINGS: `${publicPath}bookings`,
  ABOUT_US: `${publicPath}about-us`,
  TERMS: `${publicPath}terms`,
  CONTACT_US: `${publicPath}contact-us`,
  DELETE_ME: `${publicPath}delete-my-account`,
}

const userLoggedIn = getLoggedInUser();

export default (props) => (
    userLoggedIn != null ? 
    <Switch>
        <Route exact path={routeCodes.DASHBOARD} component={loadable(() => import('../pages/home')) } />
        <Route exact path={routeCodes.LOGIN} component={loadable(() => import('../pages/users')) } />
        <Route path={routeCodes.VENDORS_LIST} component={loadable(() => import('../pages/vendors'))} />
        <Route path={routeCodes.VENDOR_DETAILS+"/:id"} component={loadable(() => import('../pages/vendors/details'))} />
        <Route exact path={routeCodes.BOOKINGS} component={loadable(() => import('../pages/bookings'))} />
        <Route exact path={routeCodes.ABOUT_US} component={loadable(() => import('../pages/about'))} />
        <Route exact path={routeCodes.CONTACT_US} component={loadable(() => import('../pages/contact'))} />
        <Route exact path={routeCodes.DELETE_ME} component={loadable(() => import('../pages/userdelete'))} />
        <Route exact path={routeCodes.TERMS} component={loadable(() => import('../pages/terms'))} />
    </Switch>
    :
    <Switch>
        <Route exact path="/" render={() => (
        <Redirect to="/login"/>
        )}/>
        <Route path={routeCodes.LOGIN} component={loadable(() => import('../pages/users')) } />
        <Route exact path={routeCodes.REGISTER} component={loadable(() => import('../pages/users/register')) } />
    </Switch>
);
