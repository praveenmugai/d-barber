import React from 'react';
import { connect } from 'react-redux';
import { GET_VENDORS } from '../actions/vendorActions';
import { getLoggedInUser, asyncLocalStorage } from '../globals/utils';
import {NavLink} from "react-router-dom";
import { routeCodes } from './Routes';

const userData = getLoggedInUser();

const logout = () => {
    asyncLocalStorage.removeItem("userData").then(function (value) {
        window.location = "/login";
    });
}

const Header = () =>
<>
    <div id="header" className="page-header header-bg-custom">
        <div className="navbar navbar-expand-lg">
            <a href="index.html" className="navbar-brand d-lg-none">
                <img src="./../img/custom/logo.png" alt="..."/>
                <span className="hidden-folded d-inline l-s-n-1x d-lg-none logo-text-color">D - Barber</span>
            </a>
            <div className="collapse navbar-collapse order-2 order-lg-1" id="navbarToggler">
                <img src="./../img/custom/logo.png" alt="..." height="50"/>
                <h3 className="custom-page-title">D-BARBER</h3>
                <div className="nav-active-text-primary" data-nav>
                    <ul className="nav">
                        <li>
                            <NavLink to={routeCodes.DASHBOARD} className="">
                                <span className="nav-text">Home</span>
                            </NavLink>
                        </li>
                        {
                        userData.roleId == 1
                        ?
                        <li>
                            <NavLink to={routeCodes.BOOKINGS} className="">
                                <span className="nav-text">My Bookings</span>
                            </NavLink>
                        </li>
                        :
                        null 
                        }
                        <li>
                            <NavLink to={routeCodes.ABOUT_US} className="">
                                <span className="nav-text">About Us</span>
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to={routeCodes.CONTACT_US} className="">
                                <span className="nav-text">Contact Us</span>
                            </NavLink>
                        </li>
                        <li>
                            <NavLink to={routeCodes.TERMS} className="">
                                <span className="nav-text">Terms & Conditions</span>
                            </NavLink>
                        </li>
                    </ul>
                </div>
            </div>
            <ul className="nav navbar-menu order-1 order-lg-2">
                <li className="nav-item dropdown">
                    <a href="#" data-toggle="dropdown" className="nav-link d-flex align-items-center px-2 text-color">
                        <span className="mx-2 d-none l-h-1x d-lg-block text-right text-white">
                            <small className="text-fade d-block mb-1 text-white">Hello, Welcome</small>
                            {userData.firstName+" "+userData.lastName}</span>
                        {/* <span className="avatar w-24" ><img src="./../img/a0.jpg"
                                alt="..."/></span> */}
                    </a>
                    <div className="dropdown-menu dropdown-menu-right w mt-3 animate fadeIn">
                        <NavLink to={routeCodes.DELETE_ME} className="dropdown-item">Delete My Account</NavLink>
                        <a className="dropdown-item" onClick={logout}>Sign out</a>
                    </div>
                </li>
                <li className="nav-item d-lg-none">
                    <a className="nav-link px-1" data-toggle="modal" data-target="#aside">
                        <i data-feather="menu"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</>

const mapStateToProps = state => ({
  searchTerm: state.vendorState.searchTerm,
});

const mapDispatchToProps = dispatch => ({
  onInitialLoad: userId => dispatch({ type: GET_VENDORS, userId }),
});

export default connect(mapStateToProps, mapDispatchToProps)(Header);
