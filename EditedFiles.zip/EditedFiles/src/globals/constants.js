export const API_URL = "http://localhost:8080";
export const GROUPS = [
    { value: 'men', label: 'Men' },
    { value: 'women', label: 'Women' },
    { value: 'both', label: 'Men & Women' }
  ];

export const ROLES = [
  { value: 1, label: 'Admin' },
  { value: 2, label: 'Vendor' },
  { value: 3, label: 'Advertiser' }
];