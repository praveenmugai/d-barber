import reduxStore from "./../store";

const axios = require('axios');
const {dispatch} = reduxStore;
export function makeAPICall(url, type, postBody, dispatchKey)
{
    if(type.toLowerCase() == "get")
    {
        axios.get(url)
        .then((response) => {
            dispatch(dispatchKey(response.data));
        }, (error) => {
            console.log(error);
        });
    }
    else if(type.toLowerCase() === "post")
    {
        axios.post(url, postBody, {'Content-Type': 'multipart/form-data' })
        .then((response) => {
            dispatch(dispatchKey(response.data));
        }, (error) => {
            console.log(error);
        });
    }
    else if(type.toLowerCase() === "put" || type.toLowerCase() === "patch")
    {
        axios.patch(url, postBody, {'Content-Type': 'multipart/form-data' })
        .then((response) => {
            dispatch(dispatchKey(response.data));
        }, (error) => {
            console.log(error);
        });
    }
    else if(type.toLowerCase() === "delete")
    {
        axios.delete(url, postBody, {'Content-Type': 'multipart/form-data' })
        .then((response) => {
            dispatch(dispatchKey(response.data));
        }, (error) => {
            console.log(error);
        });
    }
}