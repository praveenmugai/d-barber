export const GET_PROFILE_DETAILS = 'GET_PROFILE_DETAILS';
export const GET_DASHBOARD_DATA = 'GET_DASHBOARD_DATA';
export const SETTINGS = 'SETTINGS';
export const SAVE_SETTINGS = 'SAVE_SETTINGS';

export function getDashboardDetails(data) {
  return {
    type: GET_DASHBOARD_DATA,
    data,
  };
}

export function getUserProfile(data) {
  return {
    type: GET_PROFILE_DETAILS,
    data,
  };
}

export function getSettings(data) {
  return {
    type: SETTINGS,
    data,
  };
}

export function saveSettings(data) {
  return {
    type: SAVE_SETTINGS,
    data,
  };
}