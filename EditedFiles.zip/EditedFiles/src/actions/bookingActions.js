export const GET_BOOKINGS = 'GET_BOOKINGS';
export const SAVE_BOOKINGS = 'SAVE_BOOKINGS';
export const GET_BOOKINGS_BY_VENDOR = 'GET_BOOKINGS_BY_VENDOR';
export const CHECK_OFFER_CODE = 'CHECK_OFFER_CODE';

export function getBookings(data) {
    return {
      type: GET_BOOKINGS,
      data,
    };
}

export function saveBookings(data) {
  return {
    type: SAVE_BOOKINGS,
    data,
  };
}

export function checkOfferCode(data) {
  return {
    type: CHECK_OFFER_CODE,
    data,
  };
}

export function getBookingsByVendor(data) {
  return {
    type: GET_BOOKINGS_BY_VENDOR,
    data,
  };
}