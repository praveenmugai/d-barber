export const GET_VENDORS = 'GET_VENDORS';
export const GET_TOP_VENDORS = 'GET_TOP_VENDORS';
export const ADD_VENDOR = 'ADD_VENDOR';
export const GET_VENDOR_DETAILS = 'GET_VENDOR_DETAILS';

export function getVendors(data) {
    return {
      type: GET_VENDORS,
      data,
    };
}

export function getTopVendors(data) {
  return {
    type: GET_TOP_VENDORS,
    data,
  };
}

export function addVendor(data) {
    return {
      type: ADD_VENDOR,
      data,
    };
}

export function getVendorDetails(data) {
    return {
      type: GET_VENDOR_DETAILS,
      data,
    };
}