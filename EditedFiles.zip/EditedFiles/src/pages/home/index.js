import React, { Component } from 'react';
import { connect } from 'react-redux';
import { GET_VENDORS, getVendors, getTopVendors } from '../../actions/vendorActions';
import { API_URL } from '../../globals/constants';
import { VENDORS_LIST, TOP_VENDORS_LIST } from '../../globals/apisList';
import { makeAPICall } from '../../globals/apiHandler';
import { searchArray } from '../../globals/utils';
import VendorCard from './vendorCard';
import TopVendorCard from './topVendorCard';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';

class VendorHome extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
        list: null,
        topVendors: null,
        currentlyEditing: null,
        loader: false,
        topVendorsLoader: false
    }
    this.modalElement = React.createRef();
  }

  componentDidMount() {
      document.title = "D-Barbar - Home";
      this.getVendorsList();
      this.getTopVendors();
  }

  componentDidUpdate(prevProps){
      if(prevProps.vendors !== this.props.vendors)
        this.setState({list: this.props.vendors, loader: false});
      if(prevProps.topvendors !== this.props.topvendors)
        this.setState({topVendors: this.props.topvendors, topVendorsLoader: false});
  }

  getVendorsList() 
  {
    this.setState({loader: true});
    const apiURL = API_URL;
    const vendorsList = VENDORS_LIST;
    makeAPICall(apiURL+vendorsList, "get", null, getVendors)
  }

  getTopVendors() 
  {
    this.setState({topVendorsLoader: true});
    const apiURL = API_URL;
    const vendorsList = TOP_VENDORS_LIST;
    makeAPICall(apiURL+vendorsList, "get", null, getTopVendors)
  }

  getGroups(group)
  {
    return group === "men" ? 
    <span className="service-for-tag man-tag">Men</span> : 
    group === "women" ? 
    <span className="service-for-tag woman-tag">Women</span> : 
    group === "both" ? 
    <span className="service-for-tag unisex-tag">Men & Women</span>
    :
    null
  }

  handleSearchKeyword(e)
  {
    this.setState({searchKey: e.target.value});
  }

  showVendors(list)
  {
    return <div className="row col-12">
    {
      list.map((vendor) => {
        return <VendorCard vendor={vendor} />
      })
    }
    </div>
  }

  showTopVendors(list)
  {
    return list.map((vendor) => {
        return <div><TopVendorCard vendor={vendor} /></div>
      })
  }

  render()
  {
    let {loader, list, searchKey, topVendors, topVendorsLoader} = this.state;
    if(searchKey !== undefined && searchKey !== "")
    {
      list = searchArray(list, searchKey);
    }

    const responsive = {
      superLargeDesktop: {
        // the naming can be any, depends on you.
        breakpoint: { max: 4000, min: 3000 },
        items: 5
      },
      desktop: {
        breakpoint: { max: 3000, min: 1024 },
        items: 4
      },
      tablet: {
        breakpoint: { max: 1024, min: 464 },
        items: 2
      },
      mobile: {
        breakpoint: { max: 464, min: 0 },
        items: 1
      }
    };

    return(
      <>
        <div className="container">
          <div className="page-hero page-container" id="page-hero">
              <div className="c-padding d-flex">
                  <div className="page-title">
                      <h2 className="text-md text-highlight">Home</h2>
                  </div>
              </div>
          </div>
          <div className="page-content page-container" id="page-content">
              <div className="c-padding">
                  {
                    topVendorsLoader != true && topVendors != null && topVendors.length > 0
                    ?
                    <>
                      <h4 className="text-md text-highlight">Top Vendors</h4>
                      <Carousel responsive={responsive}>
                        {this.showTopVendors(topVendors)}
                      </Carousel>
                    </>
                    :
                    topVendorsLoader === true 
                    ? 
                    <center>Loading...</center>
                    :
                    null
                  }
                  <div className="row table-filter-sec">
                     <div className="col-md-4">
                          <div className="table-search-sec">
                              <input value={this.state.searchKey} onChange={this.handleSearchKeyword.bind(this)} type="text" className="form-control form-control-theme search"
                                  placeholder="Type keyword"/>
                          </div>
                      </div>
                  </div>
                  <div>
                  {
                    list !== null
                    ?
                    this.showVendors(list)
                    :
                    loader === true 
                    ? 
                    <center>Loading...</center>
                    :
                    loader === false 
                    ?
                    <center>No data found</center>
                    :
                    null
                  }
                  </div>
              </div>
          </div>
        </div>
      </>
    )
  }
}

const mapStateToProps = state => ({
  vendors: state.vendorState.vendors,
  topvendors: state.vendorState.topvendors,
});

const mapDispatchToProps = dispatch => ({
  onInitialLoad: userId => dispatch({ type: GET_VENDORS, userId }),
});

export default connect(mapStateToProps, mapDispatchToProps)(VendorHome);
