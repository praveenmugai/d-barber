import React from "react";
import { API_URL } from "../../globals/constants";
import StarRatings from 'react-star-ratings';
import { routeCodes } from "../../components/Routes";
import {NavLink} from "react-router-dom";

export default (props) => {
  const {
    vendor
  } = props;

  const getBackgroundImage = (service) => 
  {
    return service.img !== undefined && service.img !== null && service.img !== "" ? API_URL+"/public/"+service.img : ""
  }
  return (
    <>
        <NavLink to={routeCodes.VENDOR_DETAILS+"/"+vendor.id} className="card category">
            <div className="media media-2x1 gd-primary">
            <a className="media-content" style={{backgroundImage:"url("+getBackgroundImage(vendor)+")"}}>
                <strong className="text-fade"></strong>
            </a>
            </div>
            <div className="card-body">
                <h5 className="card-title">{vendor.name}</h5>
            </div>
        </NavLink>
    </>
  );
};