import React from "react";
import { API_URL } from "../../globals/constants";
import StarRatings from 'react-star-ratings';
import { routeCodes } from "../../components/Routes";
import {NavLink} from "react-router-dom";

export default (props) => {
  const {
    vendor
  } = props;

  const getBackgroundImage = (service) => 
  {
    return service.img !== undefined && service.img !== null && service.img !== "" ? API_URL+"/public/"+service.img : ""
  }

  const isOpen = (vendor) => 
  {
    let closeTime = vendor.closeTime !== undefined && vendor.closeTime != "" ? vendor.closeTime.split(":")[0] : 24;
    let timeNow = new Date().getHours();
    if(timeNow < closeTime)
        return true;
    else 
        return false;
  }
  
  return (
    <>
      <div className="col-4">
        <NavLink to={routeCodes.VENDOR_DETAILS+"/"+vendor.id} className="card category">
            <div className="media media-2x1 gd-primary">
            <a className="media-content" style={{backgroundImage:"url("+getBackgroundImage(vendor)+")"}}>
                <strong className="text-fade"></strong>
            </a>
            </div>
            <div className="card-body">
                <h5 className="card-title">{vendor.name}</h5>
                <div className="row">
                    <div className="col-4">
                        
                        {
                            isOpen(vendor)
                            ? 
                            <span className="status-badge inactive-badge">Closed</span>
                            :
                            <span className="status-badge active-badge">Open</span>
                        }
                        
                    </div>
                    <div className="col-8">
                        <StarRatings
                            rating={3.5}
                            starRatedColor="#e94b64"
                            numberOfStars={5}
                            name='rating'
                            starDimension="20px"
                            starSpacing="5px"
                        />
                    </div>
                </div>
            </div>
        </NavLink>
        </div>
    </>
  );
};