import React from 'react';
import { connect } from 'react-redux';
import { API_URL } from '../../globals/constants';
import { SETTINGS } from '../../globals/apisList';
import { makeAPICall } from '../../globals/apiHandler';
import { GET_PROFILE_DETAILS, getSettings } from '../../actions/homeActions';
import { Alert } from '@material-ui/lab';

class Settings extends React.Component {
  constructor(props){
    super(props)
    this.state = {
      showMessage: false
    }
  }

  componentDidMount() {
    document.title = "D-Barbar - Contact US";
    this.getSettings()
  }

  componentDidUpdate(prevProps){
      if(prevProps.settings != this.props.settings)
      {
        let vendor = this.props.settings[0];
        this.setState({
            email: vendor.email,
            address: vendor.address,
            phone: vendor.phone
          })
      }
  }

  getSettings() 
  {
    this.setState({loader: true});
    const apiURL = API_URL;
    const vendorsList = SETTINGS;
    makeAPICall(apiURL+vendorsList, "get", null, getSettings)
  }

  handleDelete(){
    if(window.confirm("We are sorry about seeing you leave. Are you sure you want to remove your account from D-Barber?"))
    {
      this.setState({showMessage: true});
      setTimeout(() => {
        this.setState({showMessage: false});
      }, 5000);
    }
  }

  render() {
    const {email, phone, address} = this.state;
    return (
      <>
      <div id="content" class="flex">
            <div class="page-content page-container" id="page-content">
                <div class="c-padding">
                    <div class="row">
                        <div class="container">
                            <div class="contact-section">
                                {
                                  this.state.showMessage == true
                                  ?
                                  <div>
                                      <Alert severity="success" onClose={() => {this.setState({showMessage: false})}}>Your request has been submitted.</Alert>
                                      <br/>
                                  </div>
                                  :
                                  null
                                }
                                <h2 class="ct-section-head">Unsubscribe</h2>
                                <div class="row contact-fields">
                                    <div class="col-md-12 contact-info">
                                        <div class="phone row">
                                            <h4 className='delete-content'>
                                              Whether or not our services couldn't satisfy your needs your preference is our priority. If you wish to discontinue our services and completely delete your account from D-barber application you may do so by clicking the below button. As we feel sad to see you go we hope to better our services in the coming days.
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="row contact-fields">
                                  <div class="col-md-12 delete-account-info">
                                    <button onClick={() => this.handleDelete()} className="btn w-sm mb-1 btn-sm btn-rounded btn-primary custom-btn-primary">Delete my account</button>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </>
    );
  }
}


const mapStateToProps = state => ({
  settings: state.adminState.settings,
  saveSettings: state.adminState.saveSettings,
});

const mapDispatchToProps = dispatch => ({
  onInitialLoad: userId => dispatch({ type: GET_PROFILE_DETAILS, userId }),
});

export default connect(mapStateToProps, mapDispatchToProps)(Settings);