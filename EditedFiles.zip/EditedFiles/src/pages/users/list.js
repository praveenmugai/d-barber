import React, { Component } from 'react';
import { connect } from 'react-redux';
import { GET_USERS, getUsers } from '../../actions/userActions';
import { API_URL } from '../../globals/constants';
import { USERS_LIST } from '../../globals/apisList';
import { makeAPICall } from '../../globals/apiHandler';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider } from 'react-bootstrap-table2-paginator';
import {NavLink} from "react-router-dom";
import { routeCodes } from '../../components/Routes';
import {ROLES} from "./../../globals/constants";
import { searchArray } from '../../globals/utils';

class UserHome extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
        list: null,
        currentlyEditing: null,
        loader: false
    }
    this.modalElement = React.createRef();
  }

  componentDidMount() {
      document.title = "D-Barbar - Users";
      this.getUsersList();
  }

  componentDidUpdate(prevProps){
      if(prevProps.users != this.props.users)
        this.setState({list: this.props.users.filter((user) => user.roleId !== 5), loader: false});
  }

  getUsersList() 
  {
    this.setState({loader: true});
    const apiURL = API_URL;
    const vendorsList = USERS_LIST;
    makeAPICall(apiURL+vendorsList, "get", null, getUsers)
  }

  handleSearchKeyword(e)
  {
    this.setState({searchKey: e.target.value});
  }

  render()
  {
    let {loader, list, searchKey} = this.state;
    if(searchKey !== undefined && searchKey !== "")
    {
      list = searchArray(list, searchKey);
    }
    const columns = [
      {
        dataField: 'id',
        text: '#',
        sort: true,
        formatter: (cell, row, rowIndex, colIndex) => {
          return rowIndex+1
        },
        style: {minWidth:"30px", textAlign: "center"},
        headerStyle: {width:"50px", textAlign: "center"},
        classes: "text-muted"
      }, 
      {
        dataField: 'name',
        text: 'Name',
        formatter: (cell, row) => {
          return <a className="item-title text-color">{row.firstName+' '+row.lastName}</a>
        },
        classes: "flex",
        sort: true,
      }, 
      {
        dataField: 'email',
        text: 'Email',
        formatter: (cell, row) => {
          return <span className="item-title mail">{cell}</span>
        },
        classes: "text-color",
        sort: true,
      },
      {
        dataField: 'roleId',
        text: 'Role',
        formatter: (cell, row) => {
          return <span className={parseInt(row.roleId) === 1 ? "badge badge-secondary " : "badge badge-danger"}>{row.roleId !== undefined ? ROLES.filter((role) => role.value === parseInt(row.roleId))[0].label : null}</span>
        },
        classes: "text-color",
        sort: true,
      },
      {
        dataField: 'id',
        text: 'Action',
        formatter: (cell, row) => {
          return <div class="item-action dropdown"><a href="#" data-toggle="dropdown"
                      class="text-muted"><i data-feather="more-vertical">Edit</i></a>
                  <div class="dropdown-menu dropdown-menu-right bg-black" role="menu">
                      <NavLink to={routeCodes.EDIT_USER+"/"+row.id} class="dropdown-item edit">Edit</NavLink>
                      <a class="dropdown-item trash" data-toggle="modal"
                          data-target="#modal-sm">Delete</a>
                  </div>
              </div>
        }
      }
    ];

    const paginationOption = {
      showTotal: true,
      withFirstAndLast: true,
      pagination:true,
      totalSize: list === null ? 0 : list.length
    };

    return(
      <>
        <div className="container">
          <div className="page-hero page-container" id="page-hero">
              <div className="c-padding d-flex">
                  <div className="page-title">
                      <h2 className="text-md text-highlight">User</h2>
                  </div>
                  <div className="flex"></div>
                  <div>
                      <NavLink to={routeCodes.ADD_NEW_USER}>
                          <button className="btn w-sm mb-1 btn-sm btn-rounded btn-primary custom-btn-primary">Add
                              user</button>
                      </NavLink>
                  </div>
              </div>
          </div>
          <div className="page-content page-container" id="page-content">
              <div className="c-padding">
                  <div className="row table-filter-sec">
                      <div className="col-md-8">
                          <div className="btn-group">
                              <button type="button" className="btn c-btn-download">Excel</button>
                              <button type="button" className="btn c-btn-download">Csv</button>
                              <button type="button" className="btn c-btn-download">Pdf</button>
                          </div>
                      </div>
                      <div className="col-md-4">
                          <span className="table-search-title">Search:</span>
                          <div className="table-search-sec">
                              <input value={this.state.searchKey} onChange={this.handleSearchKeyword.bind(this)} type="text" className="form-control form-control-theme search"
                                  placeholder="Type keyword"/>
                          </div>
                      </div>
                  </div>
                  <div>
                  {
                    list != null
                    ?
                    <PaginationProvider
                      pagination={ paginationFactory(paginationOption) }
                    >
                      {
                        ({
                          paginationProps,
                          paginationTableProps
                        }) => (
                          <div>
                            <BootstrapTable
                              keyField="id"
                              data={ list }
                              columns={ columns }
                              { ...paginationTableProps }
                              classes="table table-theme v-middle"
                            />
                          </div>
                        )
                      }
                    </PaginationProvider>
                    :
                    loader == true 
                    ? 
                    <center>Loading...</center>
                    :
                    loader == false 
                    ?
                    <center>No data found</center>
                    :
                    null
                  }
                  </div>
                  {/* <div className="d-flex">
                      <ul className="pagination">
                          <li className="page-item disabled"><a className="page-link" href="#" aria-label="Previous"><span
                                      aria-hidden="true">&laquo;</span> <span className="sr-only">Previous</span></a>
                          </li>
                          <li className="page-item active"><a className="page-link" href="#">1 <span
                                      className="sr-only">(current)</span></a></li>
                          <li className="page-item"><a className="page-link" href="#">2</a></li>
                          <li className="page-item"><a className="page-link" href="#">3</a></li>
                          <li className="page-item"><a className="page-link" href="#">4</a></li>
                          <li className="page-item"><a className="page-link" href="#">5</a></li>
                          <li className="page-item"><a className="page-link" href="#" aria-label="Next"><span
                                      aria-hidden="true">&raquo;</span> <span className="sr-only">Next</span></a>
                          </li>
                      </ul><small className="text-muted py-2 mx-2">Showing <span>1 to 10</span> of <span
                              id="count">15</span> items</small>
                  </div> */}
              </div>
          </div>
        </div>
      </>
    )
  }
}

const mapStateToProps = state => ({
  users: state.userState.users,
});

const mapDispatchToProps = dispatch => ({
  onInitialLoad: userId => dispatch({ type: GET_USERS, userId }),
});

export default connect(mapStateToProps, mapDispatchToProps)(UserHome);
