import React, { Component } from 'react';
import { connect } from 'react-redux';
import { API_URL, ROLES } from '../../globals/constants';
import { USERS_LIST } from '../../globals/apisList';
import { makeAPICall } from '../../globals/apiHandler';
import Select from 'react-select';
import {NavLink} from "react-router-dom";
import { routeCodes } from '../../components/Routes';
import Alert from '@material-ui/lab/Alert';
import { addUser, GET_USERS } from '../../actions/userActions';
import { getVendorDetails } from '../../actions/vendorActions';

class AddVendor extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
        list: null,
        currentlyEditing: null,
        loader: false,
        status: 0,
        notification: {
            message: null,
            type: null
        },
        rolesList: ROLES
    }
    this.modalElement = React.createRef();
  }

  componentDidMount() {
      document.title = this.props.match.params.id !== undefined ? "D-Barbar - Edit - "+this.props.match.params.id : "D-Barbar - Add User";
      if(this.props.match.params.id !== undefined)
      {
          if(this.props.users !== undefined && this.props.users !== null && this.props.users.length > 0)
          {
            let vendor = this.props.users.filter((vendor) => vendor.id === this.props.match.params.id);
            vendor = vendor.length === 1 ? vendor[0] : vendor;
            let role = ROLES.filter((role) => role.value === parseInt(vendor.roleId))[0].value;
            this.setState({
              firstName: vendor.firstName,
              lastName: vendor.lastName,
              email: vendor.email,
              phone: vendor.phone,
              password: vendor.password,
              role: role
            })
          }
          else 
            this.getUser(this.props.match.params.id);
      }
  }

  componentDidUpdate(prevProps){
      if(prevProps.addUser != this.props.addUser)
      {
        if(this.props.addUser.id != undefined && this.props.addUser.id != '')
        {
            this.setState({loader: false, notification: {message: "User Added Successfully!", type : "success"}});
            document.getElementById("add-form").reset();
        }
        else 
        {
            this.setState({loader: false, notification: {message: "Error occurred while adding branch. Please try after sometimes or contact the administrator.", type : "error"}});
        }
      }
      
      if(prevProps.vendorDetails != this.props.vendorDetails)
      {
          let vendor = this.props.vendorDetails;
          let role = ROLES.filter((role) => role.value === parseInt(vendor.roleId))[0].value;
          this.setState({
            firstName: vendor.firstName,
            lastName: vendor.lastName,
            email: vendor.email,
            phone: vendor.phone,
            password: vendor.password,
            role: role
          })
      }
  }

  getUser(id) 
  {
    this.setState({loader: true});
    const apiURL = API_URL;
    const vendorsList = USERS_LIST;
    makeAPICall(apiURL+vendorsList+"/"+id, "get", null, getVendorDetails)
  }

  onRoleChange(e) 
  {
    this.setState({role: e.value});
  }

  onInputChange(key,event)
  {
      if(key !== null && key !== "" && (key === "status" || key === "featured"))
      {
        this.setState({[key]: event.target.value === "on" ? 1 : 0});
      }
      else 
      {
        this.setState({[key]: event.target.value});
      }
  }

  async onSubmit(event)
  {
    event.preventDefault();
    let postBody = new FormData();
    postBody.append("firstName",this.state.firstName);
    postBody.append("lastName",this.state.lastName);
    postBody.append("phone",this.state.phone);
    postBody.append("email", this.state.email);
    postBody.append("password", this.state.password);
    postBody.append("roleId", parseInt(this.state.role !== undefined ? this.state.role : 1));
    if(this.props.match.params.id !== undefined)
    {
        postBody.append("id", this.props.match.params.id);
    }
    
    this.setState({loader: true});
    const apiURL = API_URL;
    const vendorsList = this.props.match.params.id !== undefined ? USERS_LIST+"/"+this.props.match.params.id : USERS_LIST;
    await makeAPICall(apiURL+vendorsList, this.props.match.params.id !== undefined ? "put" : "post", postBody, addUser);
  }

  closeNotification()
  {
    this.setState(
        {
            notification:{message: null, type: null}
        }
    );
  }

  render()
  {
    const {notification} = this.state;
    
    return(
      <>
        <div className="container">
            <div className="page-hero page-container" id="page-hero">
                <div className="c-padding d-flex">
                    <div className="page-title">
                        <h2 className="text-md text-highlight">{this.props.match.params.id !== undefined ? "Edit User" : "New User"}</h2>
                    </div>
                    <div className="flex"></div>
                    <div>
                        <NavLink to={routeCodes.USERS_LIST}>
                            <button className="btn w-sm mb-1 btn-sm btn-rounded btn-primary custom-btn-primary">Back to
                                list</button>
                        </NavLink>
                    </div>
                </div>
            </div>
        </div>
        <div className="page-content page-container" id="page-content">
            <div className="c-padding">
                <div className="row">
                    <div className="col-md-12">
                        <div className="card">
                            {
                            notification.message !== null 
                            ? 
                            <div>
                                <Alert severity={notification.type} onClose={() => {this.closeNotification()}}>{notification.message}</Alert>
                                <br/>
                            </div>
                            :
                            null 
                            }
                            <div className="card-header"><strong>Create a new user</strong></div>
                            <div className="card-body">
                                <form id="add-form" enctype="multipart/form-data" onSubmit={this.onSubmit.bind(this)} method="post">
                                    <div className="row">
                                        <div className="col-md-6">
                                            <div className="form-group">
                                                <label className="text-muted" for="">First Name: <span className="required">*</span></label>
                                                <input value={this.state.firstName} required onChange={this.onInputChange.bind(this, "firstName")} type="text" className="form-control" id=""
                                                    aria-describedby="emailHelp"
                                                    placeholder="Please enter first name" />
                                            </div> 
                                        </div>
                                        <div className="col-md-6">
                                            <div className="form-group">
                                                <label className="text-muted" for="">Last Name: <span className="required">*</span></label>
                                                <input value={this.state.lastName} required onChange={this.onInputChange.bind(this, "lastName")} type="text" className="form-control" id=""
                                                    aria-describedby="emailHelp"
                                                    placeholder="Please enter last name" />
                                            </div> 
                                        </div>
                                        <div className="col-md-6">
                                            <div className="form-group">
                                                <label className="text-muted">Email: <span className="required">*</span></label>
                                                <input value={this.state.email} required onChange={this.onInputChange.bind(this, "email")} type="text" className="form-control" id=""
                                                    placeholder="name@provider.com" />
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <div className="form-group">
                                                <label className="text-muted">Phone: <span className="required">*</span></label>
                                                <input value={this.state.phone} required onChange={this.onInputChange.bind(this, "phone")} type="text" className="form-control" id=""
                                                    placeholder="9647845467" />
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <div className="form-group">
                                                <label className="text-muted">Role:</label>
                                                <Select
                                                    required
                                                    options={
                                                        this.state.rolesList
                                                    }
                                                    value={this.state.rolesList.filter(obj => this.state.role !== undefined && this.state.role === obj.value)}
                                                    onChange={this.onRoleChange.bind(this)}
                                                />
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <div className="form-group">
                                                <label className="text-muted">Password: <span className="required">*</span></label>
                                                <input value={this.state.password} required onChange={this.onInputChange.bind(this, "password")} type="password" className="form-control" id=""/>
                                            </div>
                                        </div>
                                        
                                        <div className="col-md-12 text-right">
                                            <button type="submit"
                                                className="btn btn-rounded custom-btn-primary mt-5 text-white">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </>
    )
  }
}

const mapStateToProps = state => ({
    addUser: state.userState.addUser,
    users: state.userState.users,
});

const mapDispatchToProps = dispatch => ({
  onInitialLoad: userId => dispatch({ type: GET_USERS, userId }),
});

export default connect(mapStateToProps, mapDispatchToProps)(AddVendor);
