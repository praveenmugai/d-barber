import React, { Component } from 'react';
import { connect } from 'react-redux';
import { API_URL } from '../../globals/constants';
import { LOGIN } from '../../globals/apisList';
import { makeAPICall } from '../../globals/apiHandler';
import {NavLink} from "react-router-dom";
import { routeCodes } from '../../components/Routes';
import {asyncLocalStorage} from "./../../globals/utils";
import { getUserProfile, GET_PROFILE_DETAILS } from '../../actions/homeActions';
import Alert from '@material-ui/lab/Alert';

class Login extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
        email: null,
        password: null,
        agree: 0,
        loader: false,
        error: false
    }
    this.modalElement = React.createRef();
  }

  componentDidMount() {
      document.title = "D-Barbar - Login";
  }

  componentDidUpdate(prevProps){
      if(prevProps.userData != this.props.userData && this.props.userData.id !== undefined)
      {
        asyncLocalStorage.setItem("userData", JSON.stringify(this.props.userData)).then(function (value) {
            window.location = "/";
        });
      }
      else if(prevProps.userData != this.props.userData && this.props.userData.error !== undefined)
      {
        this.setState({error: true});
      }
  }

  onInputChange(key,event)
  {
      if(key !== null && key !== "" && key == "agree")
      {
        this.setState({[key]: event.target.value == "on" ? 1 : 0});
      }
      else 
      {
        this.setState({[key]: event.target.value});
      }
  }

  async onSubmit(event)
  {
    event.preventDefault();
    let postBody = new FormData();
    postBody.append("email",this.state.email);
    postBody.append("password", this.state.password);

    this.setState({loader: true});
    const apiURL = API_URL;
    const login = LOGIN;
    await makeAPICall(apiURL+login, "post", postBody, getUserProfile);
  }

  closeNotification()
  {
    this.setState(
        {
            error: false
        }
    );
  }

  render()
  {
    const {error} = this.state;

    return(
      <>
        <div class="flex">
            <div class="col-4 w-auto-sm mx-auto py-5">
                <div class="p-4 d-flex flex-column h-100">
                    <a href="index.html" class="navbar-brand align-self-center">
                        <img src={process.env.PUBLIC_URL + "/img/custom/logo.png"} alt="logo" class="auth-logo"/>
                    </a>
                </div>
                <div class="card">
                    <div id="content-body">
                        <div class="p-3 p-md-5">
                            <h5>Welcome back!</h5>
                            <p><small class="text-muted">Login to manage your account</small></p>
                            <form id="add-form" enctype="multipart/form-data" onSubmit={this.onSubmit.bind(this)} method="post">
                                {
                                    error == true
                                    ?
                                    <div>
                                        <Alert severity="error" onClose={() => {this.closeNotification.bind(this)}}>Sorry, incorrect credentials!</Alert>
                                        <br/>
                                    </div>
                                    :
                                    null
                                }
                                <div className="form-group"><label>Email</label><input value={this.state.email} required onChange={this.onInputChange.bind(this, "email")} type="email" class="form-control"
                                        placeholder="Enter email"/></div>
                                <div className="form-group"><label>Password</label><input value={this.state.password} required onChange={this.onInputChange.bind(this, "password")} type="password" class="form-control"
                                        placeholder="Password"/>
                                    <div className="my-3 text-right"><a href="forgot-password.html" className="text-muted">Forgot
                                            password?</a></div>
                                </div>
                                <div className="checkbox mb-3"><label className="ui-check"><input value={this.state.agree == 1 ? "off" : "on"} checked={this.state.agree == 1 ? true : false} onChange={this.onInputChange.bind(this, "agree")} type="checkbox"/><i></i> Remember
                                        me</label></div><button type="submit"
                                    className="btn btn-primary mb-4 custom-btn-primary">Sign in</button>
                            </form>
                            <div>Do not have an account? <NavLink to={routeCodes.REGISTER} className="text-primary cutom-text-primary">Sign up</NavLink></div>
                        </div>
                    </div>
                </div>
                <div className="text-center text-muted">&copy; Copyright. D-barber</div>
            </div>
        </div>
      </>
    )
  }
}

const mapStateToProps = state => ({
  userData: state.adminState.userData,
});

const mapDispatchToProps = dispatch => ({
  onInitialLoad: userId => dispatch({ type: GET_PROFILE_DETAILS, userId }),
});

export default connect(mapStateToProps, mapDispatchToProps)(Login);
