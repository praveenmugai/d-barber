import React, { Component } from 'react';
import { connect } from 'react-redux';
import { API_URL } from '../../globals/constants';
import { CUSTOMERS_LIST } from '../../globals/apisList';
import { makeAPICall } from '../../globals/apiHandler';
import {NavLink} from "react-router-dom";
import { routeCodes } from '../../components/Routes';
import { GET_PROFILE_DETAILS } from '../../actions/homeActions';
import Alert from '@material-ui/lab/Alert';
import { addCustomer } from '../../actions/customerActions';

class Register extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
        email: null,
        password: null,
        agree: 0,
        loader: false,
        error: false
    }
    this.modalElement = React.createRef();
  }

  componentDidMount() {
      document.title = "D-Barbar - Register";
  }

  componentDidUpdate(prevProps){
      if(prevProps.addCustomer != this.props.addCustomer && this.props.addCustomer.id !== undefined)
      {
        window.location = "/login";
      }
      else if(prevProps.addCustomer != this.props.addCustomer && this.props.addCustomer.error !== undefined)
      {
        this.setState({error: true});
      }
  }

  onInputChange(key,event)
  {
      if(key !== null && key !== "" && key == "agree")
      {
        this.setState({[key]: event.target.value == "on" ? 1 : 0});
      }
      else 
      {
        this.setState({[key]: event.target.value});
      }
  }

  async onSubmit(event)
  {
    event.preventDefault();
    let postBody = new FormData();
    postBody.append("firstName",this.state.firstName);
    postBody.append("lastName",this.state.lastName);
    postBody.append("phone",this.state.phone);
    postBody.append("email",this.state.email);
    postBody.append("password", this.state.password);
    postBody.append("roleId", 2);
    this.setState({loader: true});
    const apiURL = API_URL;
    const login = CUSTOMERS_LIST;
    await makeAPICall(apiURL+login, "post", postBody, addCustomer);
  }

  closeNotification()
  {
    this.setState(
        {
            error: false
        }
    );
  }

  render()
  {
    const {error} = this.state;

    return(
      <>
        <div class="flex">
            <div class="col-4 w-auto-sm mx-auto py-5">
                <div class="p-4 d-flex flex-column h-100">
                    <a href="index.html" class="navbar-brand align-self-center">
                        <img src={process.env.PUBLIC_URL + "/img/custom/logo.png"} alt="logo" class="auth-logo"/>
                    </a>
                </div>
                <div class="card">
                    <div id="content-body">
                        <div class="p-3 p-md-5">
                            <h5>Welcome back!</h5>
                            <p><small class="text-muted">Login to manage your account</small></p>
                            <form id="add-form" enctype="multipart/form-data" onSubmit={this.onSubmit.bind(this)} method="post">
                                {
                                    error == true
                                    ?
                                    <div>
                                        <Alert severity="error" onClose={() => {this.closeNotification.bind(this)}}>Sorry, incorrect credentials!</Alert>
                                        <br/>
                                    </div>
                                    :
                                    null
                                }
                                <div className="form-group"><label>Firstname</label><input value={this.state.firstName} required onChange={this.onInputChange.bind(this, "firstName")} type="text" class="form-control"
                                        placeholder="Enter firstname"/></div>
                                <div className="form-group"><label>Lastname</label><input value={this.state.lastName} required onChange={this.onInputChange.bind(this, "lastName")} type="text" class="form-control"
                                        placeholder="Enter lastname"/></div>
                                <div className="form-group"><label>Phone</label><input value={this.state.phone} required onChange={this.onInputChange.bind(this, "phone")} type="text" class="form-control"
                                        placeholder="Enter phone"/></div>
                                <div className="form-group"><label>Email</label><input value={this.state.email} required onChange={this.onInputChange.bind(this, "email")} type="email" class="form-control"
                                        placeholder="Enter email"/></div>
                                <div className="form-group"><label>Password</label><input value={this.state.password} required onChange={this.onInputChange.bind(this, "password")} type="password" class="form-control"
                                        placeholder="Password"/>
                                    <div className="my-3 text-right"><a href="forgot-password.html" className="text-muted">Forgot
                                            password?</a></div>
                                </div>
                                <div className="checkbox mb-3"><label className="ui-check"><input required value={this.state.agree == 1 ? "off" : "on"} checked={this.state.agree == 1 ? true : false} onChange={this.onInputChange.bind(this, "agree")} type="checkbox"/><i></i> I Agree to terms and conditions</label></div><button type="submit"
                                    className="btn btn-primary mb-4 custom-btn-primary">Sign up</button>
                                <div>Have an account already? <NavLink to={routeCodes.LOGIN} className="text-primary cutom-text-primary">Sign in</NavLink></div>
                            </form>
                        </div>
                    </div>
                </div>
                <div className="text-center text-muted">&copy; Copyright. D-barber</div>
            </div>
        </div>
      </>
    )
  }
}

const mapStateToProps = state => ({
    addCustomer: state.customerState.addCustomer,
});

const mapDispatchToProps = dispatch => ({
  onInitialLoad: userId => dispatch({ type: GET_PROFILE_DETAILS, userId }),
});

export default connect(mapStateToProps, mapDispatchToProps)(Register);
