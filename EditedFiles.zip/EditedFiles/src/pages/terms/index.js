import React, { Component } from 'react';

class AboutUs extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
    }
  }

  componentDidMount() {
      document.title = "D-Barbar - Terms & Conditions";
  }

  render()
  {
    return(
      <>
        <div className="container">
          <div className="page-content page-container" id="page-content">
              <div className="c-padding">
              <div class="about-section">
                <h1>BOOK YOUR SEAT SAVE YOUR TIME</h1>
                <p>These terms and conditions apply as general terms and conditions for availing services (hereinafter referred to as ‘D-Barber’). Additional terms and conditions may apply in respect of the particular service and promotion . These terms and conditions are subject to change without any prior notice. Hence, customers are requested to refer to the terms and conditions from time to time and before availing any service. Further, by availing the services/purchasing products, the customer
shall be deemed to have accepted all the below mentioned Terms and Conditions and it constitutes a contract between the customer and the organization owning and running the respective D-Barber.</p>
                </div>

                <ol>
                  <li>
                    D-Barber is a Time Savings App.
                  </li>
                  <li>
                    D-Barber is an App to link all shops.
                  </li>
                  <li>
                    D-Barber is not only for Time Savings but also used to promote Salon business.
                  </li>
                  <li>
                    D-Barber may collect the following personal information from You(Customer)
                    <ul>
                      <li>
                        Name
                      </li>
                      <li>
                        User Id
                      </li>
                      <li>
                        Email address
                      </li>
                      <li>
                        Address (including country and ZIP/postal code)
                      </li>
                      <li>
                        Gender
                      </li>
                      <li>
                        Age
                      </li>
                      <li>
                        Phone number
                      </li>
                      <li>
                        Password chosen by the User
                      </li>
                      <li>
                        Other details as you may volunteer
                      </li>
                    </ul>
                  </li>
                  <li>
                    D-Barber is an App to link all shops.
                  </li>
                  <li>
                    D-Barber is an App to link all shops.
                  </li>
                </ol>
                <br/><br/>
                <p>
                  Why is this information Collected?
                </p>
                <p>
                Your account will be associated with your phone number. For example, location information we receive in connection with your use of one of our apps may be used to customize the content you see in the same or in any of our apps. The contact information you provide may be used by D-Barber to send you timely and relevant promotions.
                </p>
                <p>
                By accepting this privacy policy, you give D-Barber the right to contact you by SMS or e-mail for such promotions. D-Barber provides you, the user with deals in various categories which are highly customized to your location, indicated taste and probable use. Since the deals are time-sensitive, we need to collect the above information on a periodic basis. Your contact information is collected in order to enable you to have the best possible experience.
                </p>
                <br/>
                <p>
                  Shop’s Registration Process
                </p>
                <ol>
                  <li>
                    D– Barber may collect the following information from Shops
                    <ul>
                      <li>
                      Shop name
                      </li>
                      <li>
                      Address
                      </li>
                      <li>
                      Email address
                      </li>
                      <li>
                      Phone number
                      </li>
                      <li>
                      Stylist Name and number of persons working
                      </li>
                      <li>
                      Shop Category(Spa, saloon ,Massage Centre, Tatoos)
                      </li>
                    </ul>
                  </li>
                  <li>
                    Shops should add their services in the respective categories. The Shops should furnish their payment options, shop timing details etc.,
                  </li>
                  <li>
                    The Shops should accept to pay the service charges of 10% for every booking to D- Barber and the same should be paid at the beginning of every week or on Monday or else D-Barber will terminate the service with the respective shops.
                  </li>
                  <li>
                    D-Barber may give option for the shops to accept payment from the customers through COD or through D-Barber and the shops must have to pay the service charges (10%) to D-Barber through our payment gateway only.
                  </li>
                  <li>
                    D-Barber reserves the rights to alter the percentage of service charges.
                  </li>
                  <li>
                    Shops may clear their queries through phone or in person with D-Barber.
                  </li>
                  <li>
                    The shops must take responsibility in the safety measures of their respective portal.
                  </li>
                  <li>
                  The Shops may reduce their amount if any payable by the Company (D-Barber) and will send the remaining amount to D- Barber.
                  </li>
                  <li>
                  The shops have the rights to close their shop at any time due to some unavoidable circumstances and the booking will be cancelled automatically and the same shall be intimated to the customer and no applicable charges will be deducted from both customer and shops and the amount will be refunded to the customers without any charges deducted.
                  </li>
                </ol>
                <br/>
                <p>APPOINTMENT AND CANCELLATIONS:</p>
                <ol>
                  <li>
                  We will be happy to change/reschedule your booking with prior notice subject to availability of spare appointment slots.
                  </li>
                  <li>
                  We hold appointments for 10minutes post the booked time. In case of no show within 10minutes, your appointment shall be treated as cancelled .
                  </li>
                  <li>
                  It is advisable to cancel the appointment before 1 hour or else 10% service charges will be deducted from the booking amount(whenever you booked).
                  </li>
                </ol>
              </div>
          </div>
        </div>
      </>
    )
  }
}

export default AboutUs;
