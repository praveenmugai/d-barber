import React from 'react';
import { connect } from 'react-redux';
import { API_URL } from '../../globals/constants';
import { SETTINGS } from '../../globals/apisList';
import { makeAPICall } from '../../globals/apiHandler';
import { GET_PROFILE_DETAILS, getSettings } from '../../actions/homeActions';

class Settings extends React.Component {
  constructor(props){
    super(props)
    this.state = {}
  }

  componentDidMount() {
    document.title = "D-Barbar - Contact US";
    this.getSettings()
  }

  componentDidUpdate(prevProps){
      if(prevProps.settings != this.props.settings)
      {
        let vendor = this.props.settings[0];
        this.setState({
            email: vendor.email,
            address: vendor.address,
            phone: vendor.phone
          })
      }
  }

  getSettings() 
  {
    this.setState({loader: true});
    const apiURL = API_URL;
    const vendorsList = SETTINGS;
    makeAPICall(apiURL+vendorsList, "get", null, getSettings)
  }

  render() {
    const {email, phone, address} = this.state;
    return (
      <>
      <div id="content" class="flex">
            <div class="page-content page-container" id="page-content">
                <div class="c-padding">
                    <div class="row">
                        <div class="container">
                            <div class="contact-section">
                                <h2 class="ct-section-head">CONTACT US</h2>
                                <div class="row contact-fields">
                                    <div class="col-md-12 contact-info">
                                        <div class="phone row">
                                            <div className="col-6">
                                            <h2>Call</h2>
                                            </div>
                                            <div className="col-6">
                                            <a href={"tel:"+phone}>{phone}</a>
                                            </div>
                                        </div>
                                        <div class="email row">
                                            <div className="col-6">
                                            <h2>Email</h2>
                                            </div>
                                            <div className="col-6">
                                            <a href={"mailto:"+email}>{email}</a>
                                            </div>
                                        </div>
                                        <div class="location row">
                                            <div className="col-6">
                                            <h2>Visit</h2>
                                            </div>
                                            <div className="col-6">
                                                {address}
                                                <br/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </>
    );
  }
}


const mapStateToProps = state => ({
  settings: state.adminState.settings,
  saveSettings: state.adminState.saveSettings,
});

const mapDispatchToProps = dispatch => ({
  onInitialLoad: userId => dispatch({ type: GET_PROFILE_DETAILS, userId }),
});

export default connect(mapStateToProps, mapDispatchToProps)(Settings);