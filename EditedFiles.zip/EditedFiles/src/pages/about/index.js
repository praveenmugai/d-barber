import React, { Component } from 'react';

class AboutUs extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
    }
  }

  componentDidMount() {
      document.title = "D-Barbar - About Us";
  }

  render()
  {
    return(
      <>
        <div className="container">
          <div className="page-content page-container" id="page-content">
              <div className="c-padding">
              <div class="about-section">
                <h1>About Us </h1>
                <p>BOOK YOUR SEAT SAVE YOUR TIME</p>
                <p>About Us</p>
                </div>

                <h2 style={{textAlign: "center"}}>Our Team</h2>
                <div class="row col-12">
                    <div class="col-4">
                        <div class="card">
                        <img src="/w3images/team1.jpg" alt="Jane" style={{width:"100%"}}/>
                        <div class="container">
                            <h2>Jane Doe</h2>
                            <p class="title">CEO & Founder</p>
                            <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                            <p>jane@example.com</p>
                            <p><button class="button">Contact</button></p>
                        </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="card">
                        <img src="/w3images/team2.jpg" alt="Mike" style={{width:"100%"}}/>
                        <div class="container">
                            <h2>Mike Ross</h2>
                            <p class="title">Art Director</p>
                            <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                            <p>mike@example.com</p>
                            <p><button class="button">Contact</button></p>
                        </div>
                        </div>
                    </div>
                    
                    <div class="col-4">
                        <div class="card">
                        <img src="/w3images/team3.jpg" alt="John" style={{width:"100%"}}/>
                        <div class="container">
                            <h2>John Doe</h2>
                            <p class="title">Designer</p>
                            <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                            <p>john@example.com</p>
                            <p><button class="button">Contact</button></p>
                        </div>
                        </div>
                    </div>
                </div>
              </div>
          </div>
        </div>
      </>
    )
  }
}

export default AboutUs;
