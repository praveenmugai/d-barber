import React, { Component } from 'react';
import { connect } from 'react-redux';
import { GET_BOOKINGS, getBookings, saveBookings } from '../../actions/bookingActions';
import { API_URL } from '../../globals/constants';
import { BOOKINGS_LIST } from '../../globals/apisList';
import { makeAPICall } from '../../globals/apiHandler';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider } from 'react-bootstrap-table2-paginator';
import {NavLink} from "react-router-dom";
import { routeCodes } from '../../components/Routes';
import { searchArray, formatAMPM, getLoggedInUser } from '../../globals/utils';

class BookingHome extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
        list: null,
        currentlyEditing: null,
        loader: false
    }
    this.modalElement = React.createRef();
  }

  componentDidMount() {
      document.title = "D-Barbar - Bookings";
      this.getBookingsList();
  }

  componentDidUpdate(prevProps){
      if(prevProps.bookings !== this.props.bookings)
        this.setState({list: this.props.bookings, loader: false});
      if (prevProps.saveBookings !== this.props.saveBookings)
      {
        this.getBookingsList();
      }
  }

  getBookingsList() 
  {
    this.setState({loader: true});
    const apiURL = API_URL;
    const userData = getLoggedInUser();
    makeAPICall(apiURL+"/mybookings/"+userData.id, "get", null, getBookings)
  }

  getStatus(status)
  {
    return parseInt(status) === 2 ? 
    <span class="status-badge badge-secondary">Complete</span> : 
    parseInt(status) === 1 ? 
    <span class="status-badge confirm-badge">Confirm</span> : 
    parseInt(status) === 0 ? 
    <span class="status-badge waiting-badge">Waiting</span> :
    parseInt(status) === 5 ? 
    <span class="status-badge badge-danger">Cancelled</span>
    :
    null
  }

  getPaymentStatus(status)
  {
    return parseInt(status) === 1 ? 
    <span class="status-badge active-badge">Paid</span> : 
    parseInt(status) === 0 ? 
    <span class="status-badge inactive-badge">Unpaid</span>
    :
    null
  }

  getBookingTime(data)
  {
    let date = data.bookingDate;
    let time = data.bookingTime;
    return <div>
      {date}, {time !== undefined && time !== null && time !== "" ? formatAMPM(time.split("-")[0]) +" - "+ formatAMPM(time.split("-")[1]) : null}
    </div>
  }

  handleSearchKeyword(e)
  {
    this.setState({searchKey: e.target.value});
  }

  cancelBooking(data)
  {
    if(data != undefined && data != undefined && data.id != undefined)
    {
      var r = window.confirm("Are you sure to cancel?");
      if (r == true) {
        let postBody = new FormData();
        postBody.append("status","5");
        postBody.append("id",data.id);
        const apiURL = API_URL;
        const bookingsList = BOOKINGS_LIST;
        makeAPICall(apiURL + bookingsList+"/"+data.id, "patch", postBody, saveBookings)
      } else {
        return;
      }
      
    }
  }

  render()
  {
    let {loader, list, searchKey} = this.state;
    if(searchKey !== undefined && searchKey !== "")
    {
      list = searchArray(list, searchKey);
    }
    const columns = [
      {
        dataField: 'id',
        text: '#',
        sort: true,
        formatter: (cell, row, rowIndex, colIndex) => {
          return rowIndex+1
        },
        style:  {textAlign : "center", width: "50px"},
        headerStyle: {textAlign : "center", width: "50px"},
      }, 
      {
        dataField: 'branch',
        text: 'Branch',
        formatter: (cell, row) => {
          return <div className="text-sm h-1x">{cell}</div>
        },
        classes: "text-color",
        sort: true,
      },
      {
        dataField: 'categoryName',
        text: 'Service',
        formatter: (cell, row) => {
          return <div className="item-except text-muted text-sm h-1x">{cell}</div>
        },
        classes: "flex",
        sort: true,
      },
      {
        dataField: 'bookingTime',
        text: 'Booking Time',
        formatter: (cell, row) => {
          return this.getBookingTime(row)
        },
        classes: "text-color",
        sort: true,
        style:  {width: "250px"},
        headerStyle: {width: "250px"},
      },
      {
        dataField: 'amount',
        text: 'Amount',
        formatter: (cell, row) => {
          return "Rs. "+cell
        },
        classes: "text-color",
        sort: true,
        style:  {textAlign : "center", width: "100px"},
        headerStyle: {textAlign : "center", width: "100px"},
      },
      {
        dataField: 'paymentStatus',
        text: 'Payment',
        formatter: (cell, row) => {
          return this.getPaymentStatus(cell)
        },
        classes: "text-color",
        sort: true,
        style:  {textAlign : "center", width: "100px"},
        headerStyle: {textAlign : "center", width: "100px"},
      },
      {
        dataField: 'status',
        text: 'Status',
        formatter: (cell, row) => {
          return this.getStatus(cell)
        },
        classes: "text-color",
        sort: true,
        style:  {textAlign : "center", width: "100px"},
        headerStyle: {textAlign : "center", width: "100px"},
      },
      {
        dataField: 'id',
        text: 'Cancel',
        formatter: (cell, row) => {
          return <div className="item-action dropdown">
            {parseInt(row.status) == 0 ? <button type="text" onClick={this.cancelBooking.bind(this,row)} className="small-button btn btn-rounded custom-btn-primary mt-5 text-white">Cancel</button>: null}
        </div>
        },
        style:  {textAlign : "center", width: "70px"},
        headerStyle: {textAlign : "center", width: "70px"},
      }
    ];

    const paginationOption = {
      showTotal: true,
      withFirstAndLast: true,
      pagination:true,
      totalSize: list === null ? 0 : list.length
    };

    return(
      <>
        <div className="container">
          <div className="page-hero page-container" id="page-hero">
              <div className="c-padding d-flex">
                  <div className="page-title">
                      <h2 className="text-md text-highlight">Bookings</h2>
                  </div>
                  <div className="flex"></div>
                  <div>
                      <NavLink to={routeCodes.DASHBOARD}>
                          <button className="btn w-sm mb-1 btn-sm btn-rounded btn-primary custom-btn-primary">Home</button>
                      </NavLink>
                  </div>
              </div>
          </div>
          <div className="page-content page-container" id="page-content">
              <div className="c-padding">
                  <div className="row table-filter-sec">
                      <div className="col-md-8">
                          {/* <div className="btn-group">
                              <button type="button" className="btn c-btn-download">Excel</button>
                              <button type="button" className="btn c-btn-download">Csv</button>
                              <button type="button" className="btn c-btn-download">Pdf</button>
                          </div> */}
                      </div>
                      <div className="col-md-4">
                          <span className="table-search-title">Search:</span>
                          <div className="table-search-sec">
                              <input value={this.state.searchKey} onChange={this.handleSearchKeyword.bind(this)} type="text" className="form-control form-control-theme search"
                                  placeholder="Type keyword"/>
                          </div>
                      </div>
                  </div>
                  <div>
                  {
                    list !== null
                    ?
                    <PaginationProvider
                      pagination={ paginationFactory(paginationOption) }
                    >
                      {
                        ({
                          paginationProps,
                          paginationTableProps
                        }) => (
                          <div>
                            <BootstrapTable
                              keyField="id"
                              data={ list }
                              columns={ columns }
                              { ...paginationTableProps }
                              classes="table table-theme v-middle"
                            />
                          </div>
                        )
                      }
                    </PaginationProvider>
                    :
                    loader === true 
                    ? 
                    <center>Loading...</center>
                    :
                    loader === false 
                    ?
                    <center>No data found</center>
                    :
                    null
                  }
                  </div>
              </div>
          </div>
        </div>
      </>
    )
  }
}

const mapStateToProps = state => ({
  bookings: state.bookingState.bookings,
  saveBookings: state.bookingState.saveBookings,
});

const mapDispatchToProps = dispatch => ({
  onInitialLoad: userId => dispatch({ type: GET_BOOKINGS, userId }),
});

export default connect(mapStateToProps, mapDispatchToProps)(BookingHome);
